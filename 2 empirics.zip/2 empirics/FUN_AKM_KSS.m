fprintf('\n=================================================================')
fprintf('\nDESCRIPTION: Estimates KSS correction to AKM variance decomposition.')
fprintf('\n')
fprintf('\nINPUTS:      A file in .csv format prepared in Stata:')
fprintf('\n             - a matrix "input_dir" with seven (7) columns or variables')
fprintf('\n               ordered as: income, person ID, employer ID, year,')
fprintf('\n               education, age, lagged employer ID.')
fprintf('\n')
fprintf('\nOUTPUTS:     KSS correction to AKM variance/covariance components.')
fprintf('\n')
fprintf('\nNOTES:       - Due to changes in ichol() command, requires')
fprintf('\n             MATLAB R2011a or later.')
fprintf('\n=================================================================')
fprintf('\n')


fprintf('\n==============================================================')
fprintf('\n OPENING HOUSEKEEPING')
fprintf('\n==============================================================')
fprintf('\n  --> start timer\n')
tic

fprintf('\n  --> clear memory\n')
clc
clear

fprintf('\n  --> verify MATLAB version\n')
v = version;
v_old = (str2double(v(1:3)) < 9.1); % If MATLAB is older than version R2016b
if v_old
    fprintf('\nUSER WARNING: Implicit expansions require MATLAB R2016b or later version. Run slower routine instead.\n')
end
clear v


fprintf('\n==============================================================')
fprintf('\n SET DIRECTORIES AND PARAMETERS')
fprintf('\n==============================================================')
%Options (See Description in leave_out_KSS)   
leave_out_level = 'matches'; % 'obs' or 'matches'
type_algorithm = 'JLA'; % 'exact' or 'JLA;
simulations_JLA = 50; % default = 200
lincom_do = 0; % 0 or 1
Z_lincom = []; % matrix of observables to be used when projecting firm effects onto observables
labels_lincom = []; % vector of dimension rx1 that provides a label for each of the columns in Z_lincom

fprintf('\n  --> set paths and macros not passed from Stata\n')
try_path_1 = '/scratch/cm3594/RAIS/1_scanned_data/RAIS'; % Columbia Grid server
try_path_2 = '/Users/cm3594/Data/temp/RAIS'; % work iMac Pro or work MacBook
try_path_3 = '/Users/economoser/Data/temp/RAIS'; % personal iMac Pro
if exist(try_path_1, 'dir') % server
    DIR_INPUT = try_path_1;
    DIR_OUTPUT = try_path_1;
    DIR_LOG = '/shared/share_cmoser/15_EIMW_AER_RR/_logs';
    addpath('/shared/share_cmoser/3_MATLAB/matlab_bgl');
    cd '/shared/share_cmoser/15_EIMW_AER_RR/LeaveOutTwoWay-3.02' % Note: cd is LeaveOutTwoWay
elseif exist(try_path_2, 'dir') % local (iMac Pro)
    DIR_INPUT = try_path_2;
    DIR_OUTPUT = try_path_2;
    DIR_LOG = '/Users/cm3594/Dropbox (CBS)/Brazil/5 Code/12_EIMW_AER_RR/_logs';
    addpath('/Users/cm3594/Dropbox (CBS)/Brazil/5 Code/1 Model/matlab_bgl');
    cd '/Users/cm3594/Dropbox (CBS)/Brazil/5 Code/12_EIMW_AER_RR/LeaveOutTwoWay-3.02/' % Note: cd is LeaveOutTwoWay
elseif exist(try_path_3, 'dir') % local (MacBook)
    DIR_INPUT = try_path_3;
    DIR_OUTPUT = try_path_3;
    DIR_LOG = '/Users/cm3594/Dropbox (CBS)/Brazil/5 Code/12_EIMW_AER_RR/_logs';
    addpath('/Users/cm3594/Dropbox (CBS)/Brazil/5 Code/1 Model/matlab_bgl');
    cd '/Users/cm3594/Dropbox (CBS)/Brazil/5 Code/12_EIMW_AER_RR/LeaveOutTwoWay-3.02/' % Note: cd is LeaveOutTwoWay
else
    fprintf('\nUSER ERROR: Directory not found.\n')
    exit
end
clear try_path_1 try_path_2 try_path_3

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
path(path,'codes'); %this contains the main LeaveOut Routines.
path(path,'CMG'); % CMG package http://www.cs.cmu.edu/~jkoutis/cmg.html
[~,~] = evalc('installCMG(1)'); %installs CMG routine (silently) % CHRIS: replaced [result,output] with [~,~] on LHS so as to not store output
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fprintf('\n  --> read parameters\n')
params_dir = [DIR_INPUT '/parameters_EIMW_akm_kss.csv']; % Path to file containing AKM parameters.
file_params = fopen(params_dir);
eval(['delete ''', params_dir, ''''])
data_params = fscanf(file_params, '%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f', [15 inf])';
fclose(file_params);
n_params = 1;
year_min = data_params(:, n_params); % Minimum year.
fprintf('\n')
disp(['year_min = ' num2str(year_min)])
n_params = n_params + 1;
year_max = data_params(:, n_params); % Maximum year.
fprintf('\n')
disp(['year_max = ' num2str(year_max)])
n_params = n_params + 1;
akm_age_poly_order = data_params(:, n_params); % Age polynomial order (0 = no age controls; 1 = restricted profile of age indicators; 2 / 3 / etc. = include 2nd order term / 2nd and 3rd order terms / etc.).
fprintf('\n')
disp(['akm_age_poly_order = ' num2str(akm_age_poly_order)])
n_params = n_params + 1;
age_flat_min = data_params(:, n_params); % Minimum age for which income-age profile is restricted to be flat (only relevant if akm_age_poly_order == 1).
fprintf('\n')
disp(['age_flat_min = ' num2str(age_flat_min)])
n_params = n_params + 1;
age_flat_max = data_params(:, n_params); % Maximum age for which income-age profile is restricted to be flat (only relevant if akm_age_poly_order == 1).
fprintf('\n')
disp(['age_flat_max = ' num2str(age_flat_max)])
n_params = n_params + 1;
age_norm = data_params(:, n_params); % Normalization age.
fprintf('\n')
disp(['age_norm = ' num2str(age_norm)])
n_params = n_params + 1;
age_min = data_params(:, n_params); % Minimum age.
fprintf('\n')
disp(['age_min = ' num2str(age_min)])
n_params = n_params + 1;
age_max = data_params(:, n_params); % Maximum age.
fprintf('\n')
disp(['age_max = ' num2str(age_max)])
n_params = n_params + 1;
year_dummies = data_params(:, n_params); % Year dummies (0 = no; 1 = yes).
fprintf('\n')
disp(['year_dummies = ' num2str(year_dummies)])
n_params = n_params + 1;
edu_inter = data_params(:, n_params); % Education interactions (0 = no; 1 = yes).
fprintf('\n')
disp(['edu_inter = ' num2str(edu_inter)])
n_params = n_params + 1;
akm_hours = data_params(:, n_params); % Hours controls (0 = no; 1 = yes).
fprintf('\n')
disp(['akm_hours = ' num2str(akm_hours)])
n_params = n_params + 1;
akm_occ = data_params(:, n_params); % Occupation controls (0 = no; 1 = yes).
fprintf('\n')
disp(['akm_occ = ' num2str(akm_occ)])
n_params = n_params + 1;
akm_tenure = data_params(:, n_params); % Tenure controls (0 = no; 1 = yes).
fprintf('\n')
disp(['akm_tenure = ' num2str(akm_tenure)])
n_params = n_params + 1;
akm_exp_act = data_params(:, n_params); % Actual experience controls (0 = no; 1 = yes).
fprintf('\n')
disp(['akm_exp_act = ' num2str(akm_exp_act)])
n_params = n_params + 1;
ext = data_params(:, n_params); % File name extension string.
fprintf('\n')
disp(['ext = ' num2str(ext)])
if akm_age_poly_order == 1 && ((age_flat_min >= age_flat_max || year_min + 1 >= year_max) || (age_flat_min >= age_max || age_flat_max <= age_min))
    fprintf('\nUSER ERROR: Requested to estimate age effects (akm_age_poly_order = 1) but restricted-to-be-flat age region is too short or falls outside of selected age range.\n')
    exit
elseif akm_age_poly_order >= 2 && (age_norm < age_min || age_norm > age_max)
    fprintf('\nUSER ERROR: Requested to estimate higher-order age terms (akm_age_poly_order >= 2) but normalization age falls outside of selected age range.\n')
    exit
end
clear params_dir file_params age_min age_max data_params

fprintf('\n  --> set parallel environment\n')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                  %PARALLEL ENVIRONMENT
                  
%Note: The user should decide which set-up is most suitable given
%      her own configuration. Make sure to delete the pool once
%      estimation has been carried out.                  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
delete(gcp('nocreate')) %clear parallel envir.
c = parcluster('local');  %tell me # of available cores
job_storage_loc = strcat(DIR_OUTPUT,'/ext_',num2str(ext));
eval(['mkdir ''', job_storage_loc, ''''])
c.JobStorageLocation = job_storage_loc; % recommended to avoid storing conflicting job information (see section "Running Multiple PCT Matlab Jobs" at https://rcc.uchicago.edu/docs/software/environments/matlab/)
% nw = c.NumWorkers; %tell me # of available cores -- uncomment at next run!
nw = 5; %tell me # of available cores -- delete at next run!
parpool(c,nw,'IdleTimeout',Inf); %all cores will be assigned to Matlab
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fprintf('\n  --> set read and write paths\n')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Input File
% namesrc = [DIR_INPUT, '/temp_AKM_KSS.csv']; %where original data is

%Output File
filename=[DIR_OUTPUT '/results_AKM_KSS_' num2str(ext)]; %output file name without extension (implicitly adding .csv)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
input_dir = [DIR_INPUT '/tomatlab_' num2str(year_min) '_' num2str(year_max) '_' num2str(ext) '.csv']; % Path to file with Stata input to estimate AKM equation: income, person_ID, employer_ID, year (, age).
% output_dir = [DIR_OUTPUT '/tostata_' num2str(year_min) '_' num2str(year_max) '_' num2str(ext) '.txt']; % Path to file where MATLAB output is exported to.
clear DIR_INPUT DIR_OUTPUT year_min year_max

fprintf('\n  --> start diary (log) file\n')
ext = randi(999999, 1);
FILE_LOG = [DIR_LOG, '/log_AKM_KSS_', num2str(ext), '.log'];
eval(['diary ''', FILE_LOG, ''''])
clear DIR_LOG FILE_LOG ext


fprintf('\n==============================================================')
fprintf('\n LOAD DATA')
fprintf('\n==============================================================')
fprintf('\n  --> read input data\n')
input_file = fopen(input_dir, 'r');
input_format = '%f %f %f %u'; % always load at least 3 variables: inc, persid, empid
input_n = 4;
if akm_age_poly_order
    input_format = [input_format, ' %u'];
    input_n = input_n + 1;
end
if edu_inter
    input_format = [input_format, ' %u'];
    input_n = input_n + 1;
end
if akm_hours
    input_format = [input_format, ' %u'];
    input_n = input_n + 1;
end
if akm_occ
    input_format = [input_format, ' %u'];
    input_n = input_n + 1;
end
if akm_tenure
    input_format = [input_format, ' %u'];
    input_n = input_n + 1;
end
if akm_exp_act
    input_format = [input_format, ' %u'];
    input_n = input_n + 1;
end
fprintf('\n')
disp(['number of variables in input data = ' int2str(input_n) ' (format = ' input_format ')']);
input_data = fscanf(input_file, input_format, [input_n inf])';
fclose(input_file);
inc = input_data(:, 1); % Input data column 1: log income.
persid = input_data(:, 2); % Input data column 2: worker ID.
empid = input_data(:, 3); % Input data column 3: employer ID.
any_controls = (year_dummies | akm_age_poly_order | edu_inter | akm_hours | akm_occ | akm_tenure | akm_exp_act);
if any_controls
    col_counter = 3;
    if year_dummies
        col_counter = col_counter + 1;
        year = input_data(:, col_counter); % Additional input data: year.
    end
    if akm_age_poly_order
        col_counter = col_counter + 1;
        age = input_data(:, col_counter); % Additional input data: age.
    end
    if edu_inter
        col_counter = col_counter + 1;
        edu = input_data(:, col_counter); % Additional input data: education.
    end
    if akm_hours
        col_counter = col_counter + 1;
        hours = input_data(:, col_counter); % Additional input data: hours.
    end
    if akm_occ
        col_counter = col_counter + 1;
        occ = input_data(:, col_counter); % Additional input data: occupation codes.
    end
    if akm_tenure
        col_counter = col_counter + 1;
        tenure = input_data(:, col_counter); % Additional input data: tenure length.
    end
    if akm_exp_act
        col_counter = col_counter + 1;
        exp_act = input_data(:, col_counter); % Additional input data: actual experience (or actual experience interacted with potential experience).
    end
end
clear input_dir input_file input_format input_n input_data col_counter

fprintf('\n  --> summarize objects stored in memory\n')
whos
disp(['Mean(ln(income)) = ' num2str(mean(inc))])
disp(['Std. dev.(ln(income)) = ' num2str(std(inc))])
disp(['Var(ln(income)) = ' num2str(var(inc))])

fprintf('\n  --> descriptive statistics on complete dataset (already restricted to connected set)\n')
n_worker_years = length(inc);
fprintf('\n')
disp(['total number of worker-years = ' int2str(n_worker_years)]);
clear n_worker_years
n_workers_unique = length(unique(persid));
fprintf('\n')
disp(['number of unique workers = ' int2str(n_workers_unique)]);
clear n_workers_unique
n_employers_unique = length(unique(empid));
fprintf('\n')
disp(['number of unique employers = ' int2str(n_employers_unique)]);
clear n_employers_unique
if any_controls && year_dummies
    n_years_unique = length(unique(year));
    fprintf('\n')
    disp(['number of unique years = ' int2str(n_years_unique)]);
    clear n_years_unique
end


fprintf('\n==============================================================')
fprintf('\n ESTIMATE AKM EQUATION')
fprintf('\n==============================================================')
fprintf('\n  --> create unique indicators for workers, employers, years, ages, hours, occupations, tenure, and actual experience \n')
NT = length(inc); % Total number of worker-years.
[~, ~, id] = unique(persid);
clear persid
% N = max(persid_unique_index); % Number of unique elements in persid = number of unique workers.
[~, ~, firmid] = unique(empid);
clear empid
% J = max(empid_unique_index); % Number of unique elements in empid = number of unique employers.
if any_controls
    if year_dummies
        [~, ~, year_unique_index] = unique(year);
        clear year
        T = max(year_unique_index); % Number of unique elements in year = number of unique years.
    end
    if akm_age_poly_order == 1
        age(age >= age_flat_min & age <= age_flat_max) = age_flat_min; % Restrict income-age profile to be flat between ages age_flat_min and age_flat_max.
        clear age_flat_min age_flat_max
        [~, ~, age_unique_index] = unique(age); % Note: Command -unique()- returns unique values of age. Note: Column index (3rd assignment object) maps vector of unique entries (1st assignment object) into the original vector (argument of -unique()-).
        clear age
        N_Age = max(age_unique_index); % Number of unique elements in age = number of unique ages.
    end
    if edu_inter
        [~, ~, edu_unique_index] = unique(edu);
        clear edu
        N_Edu = max(edu_unique_index); % Number of unique elements in edu = number of unique education levels.
    end
    if akm_hours
        [~, ~, hours_unique_index] = unique(hours);
        clear hours
    %     N_H = max(hours_unique_index); % Number of unique elements in hours = number of unique contractual hours levels.
    end
    if akm_occ
        [~, ~, occ_unique_index] = unique(occ);
        clear occ
    %     N_O = max(occ_unique_index); % Number of unique elements in occ = number of unique occupation codes.
    end
    if akm_tenure
        [~, ~, tenure_unique_index] = unique(tenure);
        clear tenure
    %     N_Ten = max(tenure_unique_index); % Number of unique elements in tenure = number of unique tenure lengths.
    end
    if akm_exp_act
        [~, ~, exp_act_unique_index] = unique(exp_act);
        clear exp_act
    %     N_ExpA = max(exp_act_unique_index); % Number of unique elements in exp_act = number of unique levels of actual experience.
    end
end

% fprintf('\n  --> create worker indicators\n')
% W = sparse(1:NT, persid_unique_index', 1); % Dimension: NT x N. Note: This is the only independent variable for which no category is dropped.
% W_len = size(W, 2);
% clear persid_unique_index
% 
% fprintf('\n  --> create employer indicators\n')
% F = sparse(1:NT, empid_unique_index', 1);
% F = F(:, 2:end); % Drop indicator for first firm, or else collinear with worker effects. Dimension: NT x (J - 1).
% F_len = size(F, 2);
% clear empid_unique_index

if any_controls
    fprintf('\n  --> create (education-specific) year indicators\n')
    if year_dummies
        if edu_inter
            Y = sparse(1:NT, T*(edu_unique_index' - 1) + year_unique_index', 1);
            Y(:, T*(edu_unique_index' - 1) + 1) = []; % Drop indicator for first year of every education group, or else collinear with worker effects. Dimension: NT x (T - 1)*N_Edu.
        else
            Y = sparse(1:NT, year_unique_index', 1);
            Y = Y(:, 2:end); % Drop indicator for first year, or else collinear with worker effects. Dimension: NT x (T - 1).
            % Y = Y(:, 2:end) - sparse(Y(:, end)*ones(1, size(Y, 2) - 1)); % Work in progress: use Deaton Method as an alternative to previous line: Subtract replication of last column from entire matrix, so year effects sum to zero.  Dimension: NT x (T - 1).
        end
        Y_len = size(Y, 2);
        clear year_unique_index T
    end

    fprintf('\n  --> create age indicators or higher-order (2nd and up) terms\n')
    if akm_age_poly_order == 1
        if edu_inter
            A = sparse(1:NT, N_Age*(edu_unique_index' - 1) + age_unique_index', 1);
            A(:, N_Age*(edu_unique_index' - 1) + 1) = []; % Drop indicator for first age of every education group, or else collinear with worker effects. Dimension: NT x (N_Age - 1)*N_Edu.
        else
            A = sparse(1:NT, age_unique_index', 1);
            A = A(:, 2:end); % Drop indicator for first age, or else collinear with worker effects. Dimension: NT x (N_Age - 1).
        end
        clear age_unique_index N_Age
        A_len = size(A, 2);
    elseif akm_age_poly_order >= 2
        age = (age - age_norm)/age_norm;  % Rescale to avoid big numbers.
        if edu_inter
            E = sparse(1:NT, edu_unique_index', 1);
            if v_old
                A = zeros(NT, N_Edu*(akm_age_poly_order - 1));            
                for n = 2:akm_age_poly_order
                    A(:, N_Edu*(n - 2) + 1:N_Edu*(n - 1)) = bsxfun(@times, E, age.^n);
                end
                A = sparse(A); % Dimension: NT x (N_Age - 1)*N_Edu.
            else
                A = repmat(E, 1, akm_age_poly_order - 1).*repmat(age, 1, N_Edu*(akm_age_poly_order - 1)).^kron((2:akm_age_poly_order), ones(1, N_Edu)); % Dimension: NT x (N_Age - 1)*N_Edu.
            end
            clear E age N_Edu
        else
            if v_old
                A = zeros(NT, akm_age_poly_order - 1);
                for n = 2:akm_age_poly_order
                    A(:, n - 1) = age.^n;
                end
                A = sparse(A); % Dimension: NT x (N_Age - 1).
            else
                A = sparse(age.^(2:akm_age_poly_order)); % Dimension: NT x (N_Age - 1).
            end
            clear age
        end
        A_len = size(A, 2);
    end
    clear age_norm v_old

    fprintf('\n  --> create hours indicators\n')
    if akm_hours
        H = sparse(1:NT, hours_unique_index', 1);
        H = H(:, 2:end); % Drop indicator for first hours level, or else collinear with worker effects. Dimension: NT x (N_H - 1).
        H_len = size(H, 2);
        clear hours_unique_index
    end

    fprintf('\n  --> create occupation indicators\n')
    if akm_occ
        O = sparse(1:NT, occ_unique_index', 1);
        O = O(:, 2:end); % Drop indicator for first occupation code, or else collinear with worker effects. Dimension: NT x (N_O - 1).
        O_len = size(O, 2);
        clear occ_unique_index
    end

    fprintf('\n  --> create (education-specific) tenure indicators\n')
    if akm_tenure
    %     if edu_inter
    %         Ten = sparse(1:NT, N_Ten*(edu_unique_index' - 1) + tenure_unique_index', 1);
    %         Ten(:, N_Ten*(edu_unique_index' - 1) + 1) = []; % Drop indicator for first tenure level of every education group, or else collinear with worker effects. Dimension: NT x (N_Ten - 1)*N_Edu.
    %     else
            Ten = sparse(1:NT, tenure_unique_index', 1);
            Ten = Ten(:, 2:end); % Drop indicator for first tenure level, or else collinear with worker effects. Dimension: NT x (N_Ten - 1).
    %     end
        Ten_len = size(Ten, 2);
        clear tenure_unique_index
    end

    fprintf('\n  --> create (education-specific) actual experience indicators\n')
    if akm_exp_act
    %     if edu_inter
    %         ExpA = sparse(1:NT, N_ExpA*(edu_unique_index' - 1) + exp_act_unique_index', 1);
    %         ExpA(:, N_ExpA*(edu_unique_index' - 1) + 1) = []; % Drop indicator for first actual experience level of every education group, or else collinear with worker effects.  Dimension: NT x (N_ExpA - 1)*N_Edu.
    %     else
            ExpA = sparse(1:NT, exp_act_unique_index', 1);
            ExpA = ExpA(:, 2:end); % Drop indicator for first actual experience level, or else collinear with worker effects. Dimension: NT x (N_ExpA - 1).
    %     end
        ExpA_len = size(ExpA, 2);
        clear exp_act_unique_index
    end

    fprintf('\n  --> clear education index variable that is no longer needed\n')
    if edu_inter
        clear edu_unique_index
    end
end

fprintf('\n  --> generate design matrix (X) and Gramian matrix (X_prime*X)\n')
% X = [W, F];
% X_len = W_len + F_len; % = N + (J - 1).
controls = [];
controls_len = 0; % = N + (J - 1).
if any_controls
    if year_dummies
        controls = [controls, Y];
        controls_len = controls_len + Y_len;
        clear Y
    end
    if akm_age_poly_order >= 1
        controls = [controls, A];
        controls_len = controls_len + A_len;
        clear A
    end
    if akm_hours
        controls = [controls, H];
        controls_len = controls_len + H_len;
        clear H
    end
    if akm_occ
        controls = [controls, O];
        controls_len = controls_len + O_len;
        clear O
    end
    if akm_tenure
        controls = [controls, Ten];
        controls_len = controls_len + Ten_len;
        clear Ten
    end
    if akm_exp_act
        controls = [controls, ExpA];
        controls_len = controls_len + ExpA_len;
        clear ExpA
    end
    fprintf('\n')
    disp(['dimensions of the controls matrix (controls) = ' num2str(NT) 'x' num2str(controls_len)])
    clear NT
end

fprintf('\n  --> Run KSS code\n')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        %CALL
                        
%Note: This is where you should specify where is the input .csv file
%      and how you would like to call the log-file created by the
%      leave out functions. 
%      
%      The user should also specify where to save and name:
%      1. Log File
%      2. Saved Results (will be in .csv)
        

%Make sure that the input .csv file is sorted by worker id and year
%(xtset id year in Stata). 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    %LOAD DATA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% data=importdata(namesrc);
% id=data(:,1); % = worker ID
% firmid=data(:,2); % = employer ID
% year=data(:,3); % = year ID
% y=data(:,4); % = log income
% clear data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    %RUN LEAVE-OUT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Run
rng('default') % set seed to default (=0)
% [sigma2_psi,sigma_psi_alpha,sigma2_alpha] = leave_out_COMPLETE(inc,id,firmid,leave_out_level,controls,resid_controls,andrews_estimates,eigen_diagno,subsample_llr_fit,restrict_movers,do_SE,type_of_algorithm,epsilon,filename);
% [sigma2_psi,sigma_psi_alpha,sigma2_alpha] = leave_out_KSS(inc,id,firmid,controls,leave_out_level,type_algorithm,simulations_JLA,lincom_do,Z_lincom,labels_lincom,filename);
[~,~,~] = leave_out_KSS(inc,id,firmid,controls,leave_out_level,type_algorithm,simulations_JLA,lincom_do,Z_lincom,labels_lincom,filename);
% disp(['sigma2_psi = ' num2str(sigma2_psi)])
% disp(['sigma_psi_alpha = ' num2str(sigma_psi_alpha)])
% disp(['sigma2_alpha = ' num2str(sigma2_alpha)])


fprintf('\n==============================================================')
fprintf('\n CLOSING HOUSEKEEPING')
fprintf('\n==============================================================')
fprintf('\n  --> summarize objects stored in memory\n')
whos

fprintf('\n  --> clear memory\n')
clear

fprintf('\n  --> end timer\n')
toc

fprintf('\n  --> close parallel pool\n')
delete(gcp('nocreate')) %clear parallel envir.

fprintf('\n  --> close diary (log) file\n')
fprintf('\n\n\n\n\n\n\n\n\n\n\n\n')
diary off

fprintf('\n  --> exit\n')
exit