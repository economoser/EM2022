fprintf('\n=================================================================')
fprintf('\nDESCRIPTION: Finds the (weakly or strongly) connected set of')
fprintf('\n             employers.')
fprintf('\n')
fprintf('\nINPUTS:      - .csv file "params_dir" containing a 2x1 matrix ')
fprintf('\n               with 2 columns or parameters: indicator for')
fprintf('\n               whether set should be strongly (not weakly)')
fprintf('\n               connected, and file extension number.')
fprintf('\n             - .csv file "input_dir" containing a Mx2 matrix')
fprintf('\n               with two columns or variables: employer ID,')
fprintf('\n               lagged employer ID.')
fprintf('\n')
fprintf('\nOUTPUTS:     - .txt file "output_dir" containing a Nx1 matrix')
fprintf('\n               with one column or variable: employer ID for')
fprintf('\n               those in connected set.')
fprintf('\n')
fprintf('\nNOTES:       - If run on MATLAB version R2015b or later, then')
fprintf('\n               use MATLAB-native -conncomp()- command.')
fprintf('\n             - If run on MATLAB R2015a or earlier, then use')
fprintf('\n               MATLAB BGL package for -components()- command.')
fprintf('\n               See https://www.mathworks.com/matlabcentral/fileexchange/10922-matlabbgl.')
fprintf('\n=================================================================')
fprintf('\n')


fprintf('\n==============================================================')
fprintf('\n OPENING HOUSEKEEPING')
fprintf('\n==============================================================')
fprintf('\n  --> start timer\n')
tic

fprintf('\n  --> summarize objects stored in memory\n')
whos

fprintf('\n  --> verify MATLAB version\n')
v = version;
v_old = (str2double(v(1:3)) < 8.6); % If MATLAB is older than version R2015b.
if v_old
    fprintf('\nUSER WARNING: MATLAB native function -conncomp- requires MATLAB R2015b or later version. Using nonnative function -components- from MATLAB BGL package instead.\n')
end
clear v


fprintf('\n==============================================================')
fprintf('\n SET DIRECTORIES, PARAMETERS, AND LOG FILE')
fprintf('\n==============================================================')
fprintf('\n  --> set paths and macros not passed from Stata\n')
try_path_1 = '/scratch/cm3594/RAIS/1_scanned_data/RAIS'; % Columbia Grid server
try_path_2 = '/Users/cm3594/Data/temp/RAIS'; % work iMac Pro or work MacBook
try_path_3 = '/Users/economoser/Data/temp/RAIS'; % personal iMac Pro
if exist(try_path_1, 'dir') % server
    DIR_INPUT = try_path_1;
    DIR_OUTPUT = try_path_1;
    DIR_LOG = '/shared/share_cmoser/15_EIMW_AER_RR/_logs';
    addpath('/shared/share_cmoser/3_MATLAB/matlab_bgl');
elseif exist(try_path_2, 'dir') % local (iMac Pro)
    DIR_INPUT = try_path_2;
    DIR_OUTPUT = try_path_2;
    DIR_LOG = '/Users/cm3594/Dropbox (CBS)/Brazil/5 Code/12_EIMW_AER_RR/_logs';
    addpath('/Users/cm3594/Dropbox (CBS)/Brazil/5 Code/1 Model/matlab_bgl');
elseif exist(try_path_3, 'dir') % local (MacBook)
    DIR_INPUT = try_path_3;
    DIR_OUTPUT = try_path_3;
    DIR_LOG = '/Users/economoser/Dropbox (CBS)/Brazil/5 Code/12_EIMW_AER_RR/_logs';
    addpath('/Users/economoser/Dropbox (CBS)/Brazil/5 Code/1 Model/matlab_bgl');
else
    fprintf('\nUSER ERROR: Directory not found.\n')
    exit
end
clear try_path_1 try_path_2 try_path_3

fprintf('\n  --> read parameters\n')
params_dir = [DIR_INPUT '/parameters_EIMW_connected.csv']; % Path to file containing connected set parameters.
file_params = fopen(params_dir);
eval(['delete ''', params_dir, ''''])
clear params_dir
data_params = fscanf(file_params, '%f %f', [2 inf])'; % OLD: data_params = fscanf(file_params, '%f %f %f %f', [4 inf])';
fclose(file_params);
clear file_params
connect_strong = data_params(:, 1); % Indicator for whether employer set should be strongly connected (0 = weakly connected; 1 = strongly connected).
fprintf('\n')
disp(['connect_strong = ' num2str(connect_strong)])
ext = data_params(:, 2); % File name extension string.
fprintf('\n')
disp(['ext = ' num2str(ext)])
clear data_params

fprintf('\n  --> set read and write paths\n')
input_dir = [DIR_INPUT '/connected_input_' num2str(ext) '.csv']; % Path to file from which to read Stata input.
output_dir = [DIR_OUTPUT '/connected_output_' num2str(ext) '.txt']; % Path to file to which to write MATLAB output.
clear DIR_INPUT DIR_OUTPUT

fprintf('\n  --> start diary (log) file\n')
FILE_LOG = [DIR_LOG, '/log_connected_matlab_', num2str(ext), '.log'];
eval(['diary ''', FILE_LOG, ''''])
clear DIR_LOG FILE_LOG ext


fprintf('\n==============================================================')
fprintf('\n CONSTRUCT LARGEST CONNECTED SET')
fprintf('\n==============================================================')
fprintf('\n  --> read connected set\n')
connected_file = fopen(input_dir);
connected_data = fscanf(connected_file, '%f %f', [2 inf])';
fclose(connected_file);
id_employer = connected_data(:, 1);
lag_id_employer = connected_data(:, 2);
clear input_dir connected_file connected_data

fprintf('\n  --> create vectors for employer IDs and lagged employer IDs\n')
N_id_employer = length(id_employer);
N_lag_id_employer = length(lag_id_employer);
if N_id_employer ~= N_lag_id_employer
    fprintf('\nUSER ERROR: Not the same number of employer IDs (id_employer) and lagged employer IDs (lag_id_employer).\n')
    exit
end
[id_employer_unique, ~, index] = unique([id_employer; lag_id_employer]); % Command -unique()- returns unique values of the pooled array of all current and lagged employer IDs. Note: Column index maps 'id_employer_unique' into the (old) employer IDs: [id_employer; lag_id_employer] = id_employer_unique(index).
N_id_employer_unique = max(index);
id_employer_index = index(1:N_id_employer);
lag_id_employer_index = index(N_id_employer + 1:end);
clear N_lag_id_employer id_employer lag_id_employer index N_id_employer

fprintf('\n  --> find IDs of employers in largest (weakly or strongly) connected set\n')
if v_old % If MATLAB version is earlier than R2015b, use nonnative function -components- from MATLAB BGL package to compute connected set components.
    M = sparse(lag_id_employer_index, id_employer_index, 1); % Create sparse square matrix of old employer IDs in rows, new employer IDs in columns.
    [N_rows, N_cols] = size(M);
    if N_rows > N_cols % Ensure that employer transition matrix is square (it should be by definition).
        M = [M, sparse(N_rows, N_rows - N_cols, 0)];
    elseif N_rows < N_cols
        M = [M; sparse(N_cols - N_rows, N_cols, 0)];
    end
    if ~connect_strong
        M = max(M, M'); % Note: For weakly connected set, it does not matter if move is from employer 1 to employer 2 or from employer 2 to employer 1, since both add the same information for the purpose of constructing the weakly connected set. For strongly connected set, directionality of flows matters.
    end
    [connected_index, connected_size] = components(M); % Construct (weakly or strongly) connected sets.
    idx = find(connected_size == max(connected_size)); % Select only employer IDs in largest connected set.
    id_employer = uint32(id_employer_unique(connected_index == idx));
else % Else, if MATLAB version is R2015b or later, use MATLAB-internal function -conncomp- to compute connected set components.
    M = digraph(lag_id_employer_index', id_employer_index');
    if connect_strong
        [connected_index, connected_size] = conncomp(M, 'Type', 'strong'); % Construct weakly connected sets.
    else
        [connected_index, connected_size] = conncomp(M, 'Type', 'weak'); % Construct strongly connected sets.
    end
    idx = (connected_index == min(connected_index(connected_size(connected_index) == max(connected_size)))); % Vector of indicators for whether employer ID is in the set of employer IDs whose component set has the smallest component ID among all largest component sets.
    id_employer = uint32(id_employer_unique(idx)); % Select employer IDs in largest connected set.
end
clear N_rows N_cols v_old id_employer_unique id_employer_index lag_id_employer_index connected_index idx connected_size M

fprintf('\n  --> summary statistics\n')
disp(['number of unique firms = ' int2str(N_id_employer_unique)]);
N_id_employer_connected = size(id_employer, 1);
fprintf('\n')
if connect_strong
    disp(['number of unique firms in strongly connected set = ' int2str(N_id_employer_connected) ' (' num2str(100*N_id_employer_connected/N_id_employer_unique, '%5.2f') '%)']);
else
    disp(['number of unique firms in weakly connected set = ' int2str(N_id_employer_connected) ' (' num2str(100*N_id_employer_connected/N_id_employer_unique, '%5.2f') '%)']);
end
clear N_id_employer_connected N_id_employer_unique connect_strong

fprintf('\n  --> write IDs of employers in connected set to tab-delimited file\n')
output_file = fopen(output_dir, 'w');
fprintf(output_file, '%12s\n', 'id_employer');
fprintf(output_file, '%12.0f\n', id_employer');
fclose(output_file);
clear output_dir output_file id_employer


fprintf('\n==============================================================')
fprintf('\n CLOSING HOUSEKEEPING')
fprintf('\n==============================================================')
fprintf('\n  --> summarize objects stored in memory\n')
whos

fprintf('\n  --> clear memory\n')
clear

fprintf('\n  --> end timer\n')
toc

fprintf('\n  --> close diary (log) file\n')
fprintf('\n\n\n\n\n\n\n\n\n\n\n\n')
diary close

fprintf('\n  --> exit\n')
exit