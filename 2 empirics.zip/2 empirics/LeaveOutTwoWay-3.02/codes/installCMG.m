function [result] = installCMG(printing)
cd codes;   
MakeCMG; %installs CMG package. 
cd ..
result=1;;
end

