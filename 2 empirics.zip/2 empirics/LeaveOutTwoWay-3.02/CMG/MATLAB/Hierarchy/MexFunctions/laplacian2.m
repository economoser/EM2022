% function L = laplacian2(A,DA);
%
% return L = DA-A
%

error ('laplacian2 mexFunction not found') ;
